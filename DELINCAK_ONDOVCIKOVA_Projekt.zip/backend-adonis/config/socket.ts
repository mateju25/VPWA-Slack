/**
 * Here you can define options for socket.io server described here
 * https://socket.io/docs/v4/server-options/#socketio-server-options
 */

import type { WsConfig } from '@ioc:Ruby184/Socket.IO/Ws';

const wsConfig: WsConfig = {
  //
};

export default wsConfig;
